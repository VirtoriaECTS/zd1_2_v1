package com.example.zd1_1up

import android.content.Context
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.navigation.fragment.NavHostFragment
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [Fragment1.newInstance] factory method to
 * create an instance of this fragment.
 */
class Fragment1 : Fragment() {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null


    private lateinit var dateEditText: EditText
    private lateinit var amountEditText: EditText
    private lateinit var addButton: Button
    private lateinit var recyclerView: RecyclerView

    private val expenseList = mutableListOf<ExpenseItem>()
    private lateinit var adapter: ExpenseAdapter


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment

        val fragmentLayout=inflater.inflate(R.layout.fragment_1, container, false)
        val navController=NavHostFragment.findNavController(this)

        dateEditText = fragmentLayout.findViewById(R.id.editTextDate)
        amountEditText = fragmentLayout.findViewById(R.id.editTextAmount)
        addButton = fragmentLayout.findViewById(R.id.buttonAddExpense)
        recyclerView = fragmentLayout.findViewById(R.id.listView)

        loadExpenseList()

        adapter = ExpenseAdapter(expenseList, this)
        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(activity)

        addButton.setOnClickListener {
            addExpense()
        }

        return fragmentLayout

    }
    fun onExpenseItemClick(expenseItem: ExpenseItem) {
        // Обработка нажатия на элемент списка
        val bundle = Bundle()
        bundle.putString("date", expenseItem.date)
        bundle.putDouble("amount", expenseItem.amount)

        val navController = NavHostFragment.findNavController(this)
        navController.navigate(R.id.action_fragment1_to_fragment2, bundle)
    }

    private fun addExpense() {
        val date = dateEditText.text.toString()
        val amount = amountEditText.text.toString().toDoubleOrNull()

        if (date.isNotEmpty() && amount != null) {
            val expenseItem = ExpenseItem(date, amount)
            expenseList.add(expenseItem)
            saveExpenseList()
            adapter.notifyDataSetChanged()

            // Очищаем поля ввода
            dateEditText.text.clear()
            amountEditText.text.clear()
        } else {
            Toast.makeText(activity, "Введите корректные данные", Toast.LENGTH_SHORT).show()
        }

        loadExpenseList()
    }

    private fun saveExpenseList() {
        val gson = Gson()
        val json = gson.toJson(expenseList)

        val preferences = activity?.getPreferences(Context.MODE_PRIVATE)
        preferences?.edit()?.putString("expenseList", json)?.apply()
    }

    private fun loadExpenseList() {
        val preferences = activity?.getPreferences(Context.MODE_PRIVATE)
        val json = preferences?.getString("expenseList", "")
        val type = object : TypeToken<List<ExpenseItem>>() {}.type

        expenseList.clear()
        expenseList.addAll(Gson().fromJson(json, type) ?: emptyList())

        // Убедимся, что адаптер и RecyclerView не null перед обновлением
        if (::adapter.isInitialized && recyclerView.adapter != null) {
            adapter.notifyDataSetChanged()
        }
    }








    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment Fragment1.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            Fragment1().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }



}