package com.example.zd1_1up

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView

import com.example.zd1_1up.ExpenseItem

class ExpenseAdapterTwo(private val expenseList: List<ExpenseItem>) :
    RecyclerView.Adapter<ExpenseAdapterTwo.ExpenseViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ExpenseViewHolder {
        val view =
            LayoutInflater.from(parent.context).inflate(R.layout.recycler_disain, parent, false)
        return ExpenseViewHolder(view)
    }

    override fun onBindViewHolder(holder: ExpenseViewHolder, position: Int) {
        val expense = expenseList[position]
        holder.bind(expense)
    }

    override fun getItemCount(): Int {
        return expenseList.size
    }

    class ExpenseViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val dateTextView: TextView = itemView.findViewById(R.id.dateTextView)
        private val amountTextView: TextView = itemView.findViewById(R.id.amountTextView)

        fun bind(expense: ExpenseItem) {
            dateTextView.text = expense.date
            amountTextView.text = "${expense.amount} рублей"
        }
    }
}