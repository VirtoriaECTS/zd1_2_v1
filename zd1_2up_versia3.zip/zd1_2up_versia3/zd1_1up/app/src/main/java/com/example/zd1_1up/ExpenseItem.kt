package com.example.zd1_1up

data class ExpenseItem(
    val date: String,
    val amount: Double,
)
